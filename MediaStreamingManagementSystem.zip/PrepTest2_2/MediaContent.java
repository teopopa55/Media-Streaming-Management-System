package PrepTest2_2;

public abstract class MediaContent {

    protected String contentId;
    protected String title;

    public MediaContent(String contentId, String title) {
        this.contentId = contentId;
        this.title = title;
    }

    public abstract String getMediaInfo();
    public void validateLicense()
    {
        if(contentId==null||contentId.isEmpty()) throw new LicensingException("\nNo content ID.");
        System.out.println("\nLicense Validated.");
    }
}
