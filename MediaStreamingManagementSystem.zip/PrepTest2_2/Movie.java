package PrepTest2_2;

public class Movie extends MediaContent implements Streamable{
    private int videoQuality; //(480, 720, 1080)
    private boolean activeSession;

    public Movie(String contentId, String title) {
        super(contentId, title);
        this.activeSession=true;
    }

    @Override
    public String getMediaInfo() {
        return "Movie ["+title+"]: Playing: "+activeSession+", Quality: "+videoQuality+"p.";
    }

    @Override
    public void play() {
        System.out.println("\nMovie is playing.");
    }

    @Override
    public void pause() {
      activeSession=false;
    }

    @Override
    public boolean isPlaying() {
        return activeSession;
    }

    public void setQuality(int q){
        if(q!=480 && q!= 720 && q!=1080)
            throw new IllegalArgumentException("\nInvalid quality.");
        videoQuality=q;
    }

}
