package PrepTest2_2;

public class LicensingException extends RuntimeException {
    public LicensingException(String message) {
        super(message);
    }
    public void printMessage()
    {
        System.out.println(getMessage());
    }
}
