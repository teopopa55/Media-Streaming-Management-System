package PrepTest2_2;

public class DigitalPoster extends MediaContent{
    private String imageResolution;

    public DigitalPoster(String contentId, String title) {
        super(contentId, title);
    }

    @Override
    public String getMediaInfo() {
        return "Digital Poster: "+title+" | Image Resolution: "+imageResolution+"p";
    }
    public void updateResolution(String res)
    {
        imageResolution=res;
    }
}
