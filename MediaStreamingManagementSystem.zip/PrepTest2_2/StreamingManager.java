package PrepTest2_2;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StreamingManager {
    private List<MediaContent> library;
    private Map<String, MediaContent> contentMap;

    public StreamingManager() {
         library= new ArrayList<>();
         contentMap= new HashMap<>();
    }

    public void addContent(MediaContent mc)
    {
        library.add(mc);
        contentMap.put(mc.contentId, mc);
    }
    public void showLibrary()
    {
        for(MediaContent mc:library)
        {
            System.out.println(mc.getMediaInfo());
        }
    }
    public void pauseAllStreams()
    {
        for(MediaContent mc:library)
            if(mc instanceof Streamable)
                ((Streamable) mc).pause();
    }
    public void findById(String id)
    {
        MediaContent mc= contentMap.get(id);
        if(mc!=null) {
            System.out.println("\nId found");
            System.out.println(mc.getMediaInfo());
        }
        else System.out.println("\nId not found.");
    }
}
