package PrepTest2_2;

public class StreamingApp {
    public static void main (String[] args)
    {
        //Task 1
        try {
            MediaContent movie = new Movie("", "Home for Christmas");
            movie.validateLicense();
        }catch(LicensingException e)
        {
            System.out.println("\nValidation failed.");
        }

        //Task 2

        StreamingManager streamingManager= new StreamingManager();
        Movie movie= new Movie("M-99", "Interstellar");
        streamingManager.addContent(movie);
        DigitalPoster dg= new DigitalPoster("P-01", "Poster A");
        streamingManager.addContent(dg);

        System.out.println("\nThe library after addition is: ");
        streamingManager.showLibrary();

        //Task 3

         movie.setQuality(1080);
         movie.play();
         dg.updateResolution("4K");
        System.out.println("\nThe library after setting quality(1080) and updating resolution is: ");
        streamingManager.showLibrary();

        //Task 4

        streamingManager.findById("M-99");
        streamingManager.pauseAllStreams();
        System.out.println("\nThe library after pausing is: ");
        streamingManager.showLibrary();
    }
}
