package PrepTest2_2;

public interface Streamable {

   public void play();
   public void pause();
   public boolean isPlaying();

}
